"""
Якщо ви хочете змінити налаштування, то ви тут
"""
import random
# кількисть кадрів в секунду (в мене монітор 144гц)
FPS = 144
# колір в меню. меню входу, рег. і т д...
BG_COLOR = "#88a3d6"
# розмір вікна (не рекумендується міняти)
WIN_SIZE = (1920, 1080)
# назва, але в нас повний екран
CAPTION = 'myGeometry Dash'
# це основний шрифт
MAIN_FONT = 'Arial'
# основний колір тексту
MAIN_TEXT_COLOR = '#19202e'
# це для тексту в полях рег. та входу
INPUT_MAIN_TEXT_COLOR = '#a8b6cf'

# мова (знизу мови які поки є)
#english, ukraine
LANGUAGE = 'ukraine'







#!LANGUAGE = random.choice(['english', 'ukraine', 'french', 'german', 'spanish', 'italian', 'portuguese', 'polish', 'bulgarian'])